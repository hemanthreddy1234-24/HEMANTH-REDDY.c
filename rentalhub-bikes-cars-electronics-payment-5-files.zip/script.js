const products=[
{id:1,name:"Hero Bike",category:"bike",icon:"🏍️",price:900,unit:"day",desc:"Reliable Hero bike for city travel and trips."},
{id:2,name:"KTM Bike",category:"bike",icon:"🏍️",price:1400,unit:"day",desc:"Sporty KTM motorcycle for adventure rides."},
{id:3,name:"MT-15",category:"bike",icon:"🏍️",price:1300,unit:"day",desc:"Yamaha MT-15 style performance motorcycle."},
{id:4,name:"Yamaha R15",category:"bike",icon:"🏍️",price:1500,unit:"day",desc:"Sport bike suitable for performance-focused rides."},
{id:5,name:"RX 100",category:"bike",icon:"🏍️",price:1200,unit:"day",desc:"Classic RX 100 category rental bike."},
{id:6,name:"Tata Car",category:"car",icon:"🚗",price:2200,unit:"day",desc:"Comfortable Tata car for family travel."},
{id:7,name:"BMW Car",category:"car",icon:"🚘",price:6500,unit:"day",desc:"Premium BMW category rental car."},
{id:8,name:"Maruti Car",category:"car",icon:"🚙",price:1800,unit:"day",desc:"Economical Maruti car for everyday travel."},
{id:9,name:"Thar",category:"car",icon:"🚙",price:3500,unit:"day",desc:"SUV suitable for road trips and outdoor travel."},
{id:10,name:"Swift",category:"car",icon:"🚗",price:2000,unit:"day",desc:"Compact and practical hatchback rental."},
{id:11,name:"Kia Car",category:"car",icon:"🚘",price:2800,unit:"day",desc:"Modern Kia category car for comfortable travel."},
{id:12,name:"Canon Camera",category:"camera",icon:"📷",price:1200,unit:"day",desc:"Canon category camera for photography and events."},
{id:13,name:"Sony Camera",category:"camera",icon:"📸",price:1500,unit:"day",desc:"Sony category camera for video and photography."},
{id:14,name:"Nikon Camera",category:"camera",icon:"📷",price:1300,unit:"day",desc:"Nikon category camera for professional-style shoots."},
{id:15,name:"DJI Drone",category:"drone",icon:"🚁",price:3000,unit:"day",desc:"DJI category drone for aerial photography."},
{id:16,name:"Camera Drone",category:"drone",icon:"🛸",price:2500,unit:"day",desc:"Compact aerial camera drone for events."},
{id:17,name:"JBL Speaker",category:"speaker",icon:"🔊",price:1800,unit:"day",desc:"Portable JBL category speaker for parties and events."},
{id:18,name:"Sony Speaker",category:"speaker",icon:"🔊",price:1600,unit:"day",desc:"Sony category speaker system for music and functions."}
];

let cart=[];
let currentProduct=null;

const grid=document.getElementById("productGrid");

function renderProducts(category="all"){
grid.innerHTML="";
products.filter(p=>category==="all"||p.category===category).forEach(p=>{
grid.innerHTML+=`<article class="card"><div class="icon">${p.icon}</div><div class="card-body">
<div class="category">${p.category}</div><h3>${p.name}</h3><p>${p.desc}</p>
<div class="price">₹${p.price} / ${p.unit}</div>
<button class="btn" onclick="openProduct(${p.id})">View & Rent</button>
</div></article>`;
});
}

function openProduct(id){
currentProduct=products.find(p=>p.id===id);
document.getElementById("productDetails").innerHTML=`
<div class="big-icon">${currentProduct.icon}</div>
<h2>${currentProduct.name}</h2><p>${currentProduct.desc}</p>
<p><strong>Rental:</strong> ₹${currentProduct.price} per day</p><br>
<label>Quantity</label><input id="productQty" type="number" min="1" value="1">
<br><br><button class="btn" onclick="addToCart()">Add to Cart</button>`;
document.getElementById("productModal").classList.add("show");
}

function addToCart(){
const qty=Math.max(1,Number(document.getElementById("productQty").value));
const old=cart.find(x=>x.id===currentProduct.id);
if(old)old.qty+=qty;else cart.push({...currentProduct,qty});
closeModal("productModal");renderCart();
document.getElementById("cart").scrollIntoView({behavior:"smooth"});
}

function changeQty(id,n){
const x=cart.find(p=>p.id===id);if(!x)return;
x.qty+=n;if(x.qty<=0)cart=cart.filter(p=>p.id!==id);renderCart();
}
function removeItem(id){cart=cart.filter(p=>p.id!==id);renderCart()}

function total(){
return cart.reduce((sum,p)=>sum+p.price*p.qty,0);
}

function renderCart(){
document.getElementById("cartCount").textContent=cart.reduce((s,p)=>s+p.qty,0);
const box=document.getElementById("cartBox");
if(!cart.length){box.innerHTML='<div class="empty">Your rental cart is empty.</div>';return;}
let html="";
cart.forEach(p=>{
html+=`<div class="cart-row"><div><strong>${p.icon} ${p.name}</strong><br>₹${p.price} × ${p.qty} day/item = ₹${p.price*p.qty}</div>
<div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><b>${p.qty}</b><button onclick="changeQty(${p.id},1)">+</button>
<button class="remove" onclick="removeItem(${p.id})">Remove</button></div></div>`;
});
html+=`<div class="total">Total: ₹${total()}</div>`;
box.innerHTML=html;
}

document.querySelectorAll(".filter").forEach(btn=>btn.onclick=()=>{
document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));
btn.classList.add("active");renderProducts(btn.dataset.category);
});

document.getElementById("menuBtn").onclick=()=>document.getElementById("navLinks").classList.toggle("show");

function closeModal(id){document.getElementById(id).classList.remove("show")}

document.getElementById("bookingForm").onsubmit=e=>{
e.preventDefault();
if(!cart.length){alert("Please add at least one rental item.");return;}
const start=new Date(document.getElementById("startDate").value);
const end=new Date(document.getElementById("endDate").value);
if(end<start){alert("End date must be after or equal to start date.");return;}
const days=Math.max(1,Math.ceil((end-start)/(1000*60*60*24))+1);
document.getElementById("paymentAmount").textContent=`Rental estimate: ₹${total()*days}`;
document.getElementById("paymentModal").dataset.days=days;
document.getElementById("paymentModal").classList.add("show");
};

document.getElementById("payBtn").onclick=()=>{
const method=document.querySelector('input[name="payment"]:checked').value;
const name=document.getElementById("customerName").value;
const days=document.getElementById("paymentModal").dataset.days||1;
const amount=total()*days;
const upi=document.getElementById("upiId").value.trim();
if(!upi){alert("For this demo, enter a UPI ID such as name@upi.");return;}
closeModal("paymentModal");
document.getElementById("successText").textContent=
`${name}, your rental request for ${days} day(s) has been recorded. Demo payment method: ${method}. Amount: ₹${amount}.`;
document.getElementById("successModal").classList.add("show");
cart=[];renderCart();
};

renderProducts();
renderCart();
